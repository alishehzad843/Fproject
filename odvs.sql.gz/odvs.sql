-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 20, 2021 at 09:15 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `odvs`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `studentid` int(20) NOT NULL,
  `studentname` varchar(100) NOT NULL,
  `fathername` varchar(100) NOT NULL,
  `studentimage` varchar(200) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(50) NOT NULL,
  `cnic` int(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `city` varchar(50) NOT NULL,
  `postal address` varchar(200) NOT NULL,
  `permanent address` varchar(200) NOT NULL,
  `program` varchar(30) NOT NULL,
  `matricmarks` int(10) NOT NULL,
  `matricrollno` int(10) NOT NULL,
  `intermarks` int(10) NOT NULL,
  `interrollno` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`studentid`, `studentname`, `fathername`, `studentimage`, `dob`, `gender`, `cnic`, `email`, `phone`, `city`, `postal address`, `permanent address`, `program`, `matricmarks`, `matricrollno`, `intermarks`, `interrollno`) VALUES
(1, 'Shehzad Ali', 'Ghulam Jaffer', 'E:\\xampp\\htdocs\\mobileshopp\\Images', '2000-01-16', 'Male', 384038595, 'alishehzad843@gmail.com', '03460786377', 'sargodha', 'House # 153, Canal view', 'House # 153, Canal view', 'BSIT', 800, 895632, 850, 896523);

-- --------------------------------------------------------

--
-- Table structure for table `usertbl`
--

CREATE TABLE `usertbl` (
  `userid` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phoneno` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usertbl`
--

INSERT INTO `usertbl` (`userid`, `name`, `email`, `password`, `phoneno`) VALUES
(1, 'ali', 'ali@gmail.com', 'ali123', 0),
(2, 'usman', 'usman123@gmail.com', 'usman123', 2147483647);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`studentid`);

--
-- Indexes for table `usertbl`
--
ALTER TABLE `usertbl`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `studentid` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `usertbl`
--
ALTER TABLE `usertbl`
  MODIFY `userid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
